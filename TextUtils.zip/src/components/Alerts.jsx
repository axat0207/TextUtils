import React from 'react'

function Alerts() {
    // const [alert, setalert] = useState(null)
    // const showAlert 
  return (
    <div>
        <div class="bg-purple-200 border border-purple-400 text-black-700 px-4 py-3 rounded relative" role="alert">
  <span class=""></span>
  
</div>
    </div>
  )
}

export default Alerts